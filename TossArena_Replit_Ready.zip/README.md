# TossArena Replit
Upload/import this project into Replit and press Run. It starts with `node server.js`.
Open the web preview. Admin monitor is `/admin.html`.
Optional: create a Replit Secret named `TOSS_SECRET`.
Virtual coins only; no deposits, withdrawals, or real-money wagering.
The server generates one deterministic result per 60-second period so connected clients see the same result.
