
const express=require("express"),crypto=require("crypto"),fs=require("fs");
const app=express(),PORT=process.env.PORT||3000,FILE="state.json";
app.use(express.json());app.use(express.static("public"));
let s={period:"",bets:[],history:[]};try{s=JSON.parse(fs.readFileSync(FILE))}catch{}
const secret=process.env.TOSS_SECRET||"demo-secret-change-this";
const period=()=>String(Math.floor(Date.now()/60000));
function result(p){let h=crypto.createHash("sha256").update(secret+"|"+p).digest("hex");return{period:p,team:parseInt(h.slice(0,2),16)%2?"PAKISTAN":"INDIA",toss:parseInt(h.slice(2,4),16)%2?"TAILS":"HEADS"}}
function sync(){let p=period();if(s.period!==p){if(s.period)s.history.unshift(result(s.period));s.history=s.history.slice(0,50);s.period=p;s.bets=[];fs.writeFileSync(FILE,JSON.stringify(s))}}
app.get("/api/live",(q,r)=>{sync();let p=period(),pool={INDIA:0,PAKISTAN:0};s.bets.forEach(b=>pool[b.team]+=b.amount);r.json({period:p,seconds:60-(Math.floor(Date.now()/1000)%60),result:result(p),pool,history:[result(p),...s.history].slice(0,50)})});
app.post("/api/bet",(q,r)=>{sync();let{team,toss,amount}=q.body||{};if(!["INDIA","PAKISTAN"].includes(team)||!["HEADS","TAILS"].includes(toss)||!Number.isInteger(amount)||amount<1)return r.status(400).json({error:"Invalid"});s.bets.push({team,toss,amount});fs.writeFileSync(FILE,JSON.stringify(s));r.json({ok:true})});
app.get("/api/admin",(q,r)=>{sync();r.json(s)});
app.post("/api/admin/clear",(q,r)=>{s.bets=[];fs.writeFileSync(FILE,JSON.stringify(s));r.json({ok:true})});
app.listen(PORT,()=>console.log("TossArena running"));
